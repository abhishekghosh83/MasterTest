/*************************************************************************************************
 * This file is part of the Nebula Logger project, released under the MIT License.               *
 * See LICENSE file or go to https://github.com/jongpie/NebulaLogger for full license details.   *
 ************************************************************************************************/

import { LightningElement, api, track, wire } from 'lwc';
import { refreshApex } from '@salesforce/apex';

import getQueryResult from '@salesforce/apex/RelatedLogEntriesController.getQueryResult';
export default class RelatedLogEntries extends LightningElement {
  /* eslint-disable @lwc/lwc/no-api-reassignments */
  @api recordId;
  @api fieldSetName;
  @api sortBy = '';
  @api sortDirection = '';
  @api rowLimit;
  @api search = '';
  @api queryResult;

  @track wiredResult;
  @track isLoading = true;
  @track shouldEnableStrictSearch = true;

  get title() {
    return this.queryResult ? this.queryResult.labelPlural + ' (' + this.queryResult.records.length + ')' : '';
  }

  get showComponent() {
    return this.queryResult?.isAccessible === true;
  }

  @api
  handleSort(event) {
    this.isLoading = true;
    this.sortBy = event.detail.fieldName;
    this.sortDirection = event.detail.sortDirection;
  }

  @api
  handleSearchChange(event) {
    this.isLoading = true;
    this.search = event.target.value;
  }

  @wire(getQueryResult, {
    fieldSetName: '$fieldSetName',
    recordId: '$recordId',
    rowLimit: '$rowLimit',
    search: '$search',
    sortByFieldName: '$sortBy',
    sortDirection: '$sortDirection',
    shouldEnableStrictSearch: '$shouldEnableStrictSearch'
  })
  wiredLogEntries(result) {
    this.isLoading = true;
    this.wiredResult = result;
    if (result.data) {
      this.queryResult = this.processResult(result.data);
    } else if (result.error) {
      /* eslint-disable-next-line no-console */
      console.log(result.error);
    }
    this.isLoading = false;
  }

  async refresh() {
    this.isLoading = true;
    await refreshApex(this.wiredResult);
    this.isLoading = false;
  }

  // Parse the Apex results & add any UI-specific attributes based on field metadata
  processResult(queryResult) {
    if (queryResult.fieldSet === undefined) {
      return null;
    }

    queryResult = Object.assign({}, queryResult); // clone queryResult

    let fieldSet = Object.assign({}, queryResult.fieldSet); // clone fieldSet
    let fields = [].concat(queryResult.fieldSet.fields); // clone fields
    let records = [].concat(queryResult.records); // clone records

    for (let i = 0; i < fieldSet.fields.length; i++) {
      let field = Object.assign({}, fieldSet.fields[i]); // clone field

      if (field.type === 'datetime') {
        field.type = 'date';
        // FIXME and make dynamic based on user prefences for datetimes
        field.typeAttributes = {
          month: '2-digit',
          day: '2-digit',
          year: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit'
        };
      } else if (field.type === 'reference') {
        let displayFieldName = field.lookupDisplayFieldName.replace('.', '') + 'Display';
        let looupFieldName = field.fieldName;

        // Add URL formatting to the field
        field.type = 'url';
        field.typeAttributes = {
          label: { fieldName: displayFieldName },
          name: { fieldName: looupFieldName },
          target: '_self'
        };

        // Add the link to each log entry record
        for (let j = 0; j < records.length; j++) {
          let record = Object.assign({}, records[j]); //cloning object

          let parentObject = record[field.relationshipName];
          record[displayFieldName] = parentObject[field.lookupDisplayFieldName.split('.').splice(1)];
          record[field.fieldName] = '/' + record[looupFieldName];

          records[j] = record;
        }
      } else if (field.isNameField) {
        // Make the record's Name field a clickable link to the record
        let displayFieldName = field.fieldName + 'Display';

        // Add URL formatting to the field
        field.type = 'url';
        field.typeAttributes = {
          label: { fieldName: displayFieldName },
          name: { fieldName: 'Id' },
          target: '_self'
        };

        // Add the link to each log entry record
        for (let j = 0; j < records.length; j++) {
          let record = Object.assign({}, records[j]); //cloning object
          record[displayFieldName] = record[field.fieldName];
          record[field.fieldName] = '/' + record.Id;

          records[j] = record;
        }
      }

      fields[i] = field;
    }

    queryResult.fieldSet = fieldSet;
    queryResult.fieldSet.fields = fields;
    queryResult.records = records;

    return queryResult;
  }
}
